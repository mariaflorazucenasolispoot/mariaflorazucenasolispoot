Programa: Tabla Hash con sondeo lineal

Descripción:
Programa en C para almacenar, buscar y eliminar estudiantes en una tabla hash usando sondeo lineal. La clave es la matrícula (hasta 6 dígitos numéricos).

Archivos:
- `hashtable.h` - Definición de la estructura `Student` y prototipos.
- `hashtable.c` - Implementación de la tabla hash (insertar, buscar, eliminar, imprimir).
- `main.c` - Interfaz de consola para manejar la tabla (entrada manual de atributos).


Compilación (terminal):

gcc main.c hashtable.c -o programa.exe


Ejecución:

./programa.exe


Uso:
- Seleccione la opción del menú.
- Matrícula: sólo números, hasta 6 dígitos.
- Campos adicionales: nombre, apellido, edad, carrera (entrada por teclado).

Notas:
- La tabla tiene tamaño `TABLE_SIZE` (definido en `hashtable.h`). Puede ajustarse según necesidad.
- Para colisiones se usa sondeo lineal; el borrado marca la ranura como "borrada" para mantener la continuidad del sondeo.
